## Énoncé

L'utilisateur saisit le mot *pierre*, *feuille* ou *ciseau*, l'ordinateur choisit aléatoirement l'une des trois possibilités, et la partie commence !

## Détails

* Le mot peut tout aussi bien être saisi en minuscules qu'en majuscules.

## Rappels

* Si le joueur et l'ordinateur font le même choix on obtient une égalité.
* Le ciseau est écrasé par la pierre (la pierre gagne, le ciseau perd).
* La feuille est découpée par le ciseau (le ciseau gagne, la feuille perd).
* La pierre est enveloppée par la feuille (la feuille gagne, la pierre perd).