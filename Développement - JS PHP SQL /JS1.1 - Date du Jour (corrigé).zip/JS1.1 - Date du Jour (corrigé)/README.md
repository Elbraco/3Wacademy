## Enoncé

Afficher dynamiquement la date du jour en HTML sous la forme “Nous sommes le Mardi 11 Février 2014”.

## Détails

* Il va falloir se servir de tableaux pour afficher en français les noms des jours de la semaine et des mois...

## Rappels

* La classe *Date* possède une méthode pour extraire chaque partie de la date et de l'heure
* Attention aux valeurs renvoyées par chaque méthode, **bien lire la documentation**