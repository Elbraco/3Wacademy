<?php

interface PixelAvatarMatrixInterface {

    public function getRandom();
    public function getSize();
}