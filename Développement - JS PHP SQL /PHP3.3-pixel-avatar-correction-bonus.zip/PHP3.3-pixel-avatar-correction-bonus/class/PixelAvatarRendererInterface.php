<?php

interface PixelAvatarRendererInterface {

    public function render(PixelAvatarMatrixInterface $matrix);
}