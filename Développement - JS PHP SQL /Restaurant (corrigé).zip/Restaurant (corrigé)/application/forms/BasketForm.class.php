<?php

class BasketForm extends Form
{
    public function build()
    {
        $this->addFormField('??');
        $this->addFormField('??');
        $this->addFormField('??');
        $this->addFormField('??');
    }
}