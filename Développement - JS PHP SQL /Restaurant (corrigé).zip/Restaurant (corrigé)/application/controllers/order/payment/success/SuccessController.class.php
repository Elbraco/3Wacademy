<?php


class SuccessController
{
	public function httpGetMethod()
	{
	}
}