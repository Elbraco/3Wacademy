<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:host=localhost;dbname=resto;charset=UTF8';
$config['password'] = 'root';
$config['user']     = 'root';