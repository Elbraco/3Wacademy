<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = '';
$config['password'] = '';
$config['user']     = '';